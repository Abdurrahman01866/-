package com.evotype.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import kotlin.math.max

class EvoTypeImeService : InputMethodService() {
    private var keyboard: NovaKeyboardView? = null
    override fun onCreateInputView(): View {
        keyboard = NovaKeyboardView(this) { action -> handleKey(action) }
        return keyboard!!
    }
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        keyboard?.invalidate()
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> ic.commitText("\n", 1)
            "space" -> ic.commitText(" ", 1)
            "⇧" -> keyboard?.toggleShift()
            "?123" -> keyboard?.toggleSymbols()
            "EN/বাং" -> keyboard?.toggleLanguage()
            else -> ic.commitText(key, 1)
        }
    }
}

private class NovaKeyboardView(context: android.content.Context, val onKey: (String) -> Unit) : View(context) {
    private val navy = Color.rgb(12, 18, 36)
    private val key = Color.rgb(34, 43, 68)
    private val special = Color.rgb(54, 62, 96)
    private val accent = Color.rgb(130, 116, 255)
    private val white = Color.rgb(247, 248, 255)
    private val sub = Color.rgb(166, 176, 204)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shifted = false
    private var symbols = false
    private var bangla = false
    private data class KeyBox(val label: String, val rect: RectF, val action: String, val color: Int)
    private val boxes = mutableListOf<KeyBox>()

    fun toggleShift() { shifted = !shifted; invalidate() }
    fun toggleSymbols() { symbols = !symbols; invalidate() }
    fun toggleLanguage() { bangla = !bangla; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(navy)
        boxes.clear()
        val w = width.toFloat(); val h = height.toFloat()
        val pad = w * .025f; val gap = w * .012f
        // Header strip
        paint.color = Color.rgb(19, 27, 51)
        canvas.drawRoundRect(RectF(pad, h*.035f, w-pad, h*.19f), 18f, 18f, paint)
        drawText(canvas, if (bangla) "বাংলা মোড" else "EvoType", pad+w*.055f, h*.13f, h*.043f, white, true)
        drawText(canvas, "⌄", w-pad-w*.08f, h*.13f, h*.06f, sub, false)
        val rows = if (symbols) listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("@","#","$","%","&","-","+","(",")","/"),
            listOf("=","*","\"","'",":",";","!","?"),
            listOf("ABC",".",",","?123","space","⌫","↵")
        ) else listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("?123",",","EN/বাং","space",".","↵")
        )
        val top = h*.235f; val bottom = h*.96f
        val rowGap = h*.018f; val rowH = (bottom-top-rowGap*3)/4f
        rows.forEachIndexed { ri, row ->
            val widths = row.map { label -> when(label) { "space" -> 3.1f; "EN/বাং" -> 1.65f; "?123","ABC","⇧","⌫","↵" -> 1.35f; else -> 1f } }
            val total = widths.sum()
            val unit = (w-pad*2-gap*(row.size-1))/total
            var x = pad
            row.forEachIndexed { ci, raw ->
                val ww = unit*widths[ci]
                val y = top+ri*(rowH+rowGap)
                val rect = RectF(x, y, x+ww, y+rowH)
                val specialKey = raw in listOf("space","EN/বাং","?123","ABC","⇧","⌫","↵")
                val color = when { raw == "↵" -> accent; specialKey -> special; else -> key }
                paint.color = color
                canvas.drawRoundRect(rect, 11f, 11f, paint)
                val label = when {
                    raw == "space" -> "English  •  বাংলা"
                    raw.length == 1 && raw[0].isLetter() && shifted -> raw.uppercase()
                    else -> raw
                }
                val size = when(raw) { "space" -> h*.035f; "EN/বাং" -> h*.031f; else -> h*.052f }
                drawCentered(canvas, label, rect, size, if (raw == "↵") Color.WHITE else white, specialKey)
                val action = when(raw) { "ABC" -> "?123"; else -> raw }
                boxes.add(KeyBox(label, rect, action, color))
                x += ww+gap
            }
        }
    }

    private fun drawText(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        paint.color=color; paint.textSize=size; paint.typeface=if(bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.DEFAULT
        c.drawText(s,x,y,paint)
    }
    private fun drawCentered(c: Canvas, s: String, r: RectF, size: Float, color: Int, bold: Boolean) {
        paint.color=color; paint.textSize=size; paint.typeface=if(bold) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.DEFAULT
        val tw=paint.measureText(s); val fm=paint.fontMetrics
        val x=r.centerX()-tw/2; val y=r.centerY()-(fm.ascent+fm.descent)/2
        c.drawText(s,x,y,paint)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            boxes.firstOrNull { it.rect.contains(event.x,event.y) }?.let { box ->
                when (box.action) {
                    "EN/বাং" -> { bangla = !bangla; invalidate() }
                    "?123" -> { symbols = !symbols; invalidate() }
                    "ABC" -> { symbols = false; invalidate() }
                    else -> onKey(if (box.action == "space") "space" else box.action)
                }
            }
            return true
        }
        return true
    }
}
