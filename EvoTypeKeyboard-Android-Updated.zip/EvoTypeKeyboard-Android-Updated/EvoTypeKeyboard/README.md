# EvoType Keyboard — Android Starter

An Android Input Method (IME) starter project branded with the supplied EvoType Keyboard logo.

## Branding included
- App launcher icon: supplied keyboard-symbol artwork.
- App home screen: supplied horizontal EvoType Keyboard logo, adapted for the dark background.
- Keyboard header: EvoType wordmark.
- Android app and input-method labels: EvoType Keyboard.
- Application ID: `com.evotype.keyboard`.

## Requirements
- Android Studio (recommended for Android SDK setup) or VS Code with Android tooling
- JDK 17
- Android SDK Platform 35 and Build Tools
- Gradle 8.9+ (Android Gradle Plugin 8.7.3)

## Open and run
1. Extract the ZIP.
2. Open the `EvoTypeKeyboard` folder in Android Studio or VS Code.
3. Allow Gradle to sync.
4. Connect an Android device with USB debugging enabled, or start an emulator.
5. Run the `app` configuration.
6. In the app, tap **Enable EvoType Keyboard**, enable it in Android settings, then tap **Choose keyboard** and select EvoType Keyboard.

## Build APK from terminal
On macOS/Linux: `./gradlew assembleDebug`
On Windows: `gradlew.bat assembleDebug`
The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Current starter scope
- Custom-drawn English QWERTY keyboard
- Basic symbol layout, shift, backspace, space and enter
- Language toggle UI
- Android IME service integration

## Not implemented yet
- Full Bangla native layout and Banglish-to-Bangla transliteration engine
- Suggestions, dictionary, autocorrection, themes and personalization

This is a starter implementation, not a production-ready keyboard. Test thoroughly on target Android versions before release.
